// Runtime Configuration
// File ini bisa diedit langsung di server setelah build
window.APP_CONFIG = {
  API_BASE_URL: 'http://149.28.155.78:5007'
};
